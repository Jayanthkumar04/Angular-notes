import { Component } from '@angular/core';
import { VisitingcardComponent } from '../visitingcard/visitingcard.component';
import { User } from '../User';


@Component({
  selector: 'app-first',
  standalone: true,
  imports: [VisitingcardComponent],
  templateUrl: './first.component.html',
  styleUrl: './first.component.css'
})
export class FirstComponent {

  userInput:User[]=[];
  
  // constructor(){
    
  //   this.userInput.userName="yashwanth",
  //   this.userInput.title="pyton dev",
  //   this.userInput.salary="2000000",
  //   this.userInput.department="3",
  //   this.userInput.address=[
  //     'khammam',
  //     'narsinghi'
  //   ],
  //   this.userInput.phones=[
  //     "1234",
  //     "5678"
  //   ]

  

  // }


  constructor()
  {

    const user1:User={

      userName: "Yashwanth",
      title: "Python Dev",
      salary: "2000000",
      department: "3",
      address: ['Khammam', 'Narsinghi'],
      phones: ["1234", "5678"]

    }

    const user2:User={

      userName: "jayanth kumar",
      title: "java Dev",
      salary: "3000000",
      department: "2",
      address: ['kurnool', 'banjarahills'],
      phones: ["1234", "5678"]

    }


    this.userInput.push(user1,user2);

  }



}
